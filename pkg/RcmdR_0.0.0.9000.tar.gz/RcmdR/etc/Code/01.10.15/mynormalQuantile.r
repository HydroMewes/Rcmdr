myGumbelQuantilesFunction <- function () 
{
    distributionQuantiles("gumbel")
}
