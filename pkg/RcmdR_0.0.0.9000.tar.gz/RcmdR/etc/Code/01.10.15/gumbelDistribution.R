gumbelDistribution <- function(){
  
}